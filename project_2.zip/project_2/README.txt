README.txt

TO COMPILE:
	g++ main.cpp

TO RUN:
	./a.out